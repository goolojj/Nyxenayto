package com.nyx3n.client;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.PhantomEntity;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

public class Nyx3nEngine {
    private final Nyx3nConfig cfg;

    private String statusText = "GUARDING";
    private String radarText = "";

    private BlockPos currentGoalBlock = null;
    private BlockPos activeBreakPos = null;
    private int breakTicks = 0;
    private int walkStuckTicks = 0;
    private Vec3d lastWalkPos = null;
    private final Set<BlockPos> skippedBlocks = new HashSet<>();
    private int skipClearTimer = 0;

    // First-hit retaliation & HT3 Combat state
    private LivingEntity vengeanceTarget = null;
    private int vengeanceTimer = 0;
    private int lastHurtTime = 0;
    private int attackDelayTicks = 0;
    private int critWaitTicks = 0;
    private int strafeDir = 1;
    private int strafeFlipTimer = 0;

    private int placeCooldown = 0;
    private int wanderTicks = 0;

    private BlockPos houseOrigin = null;
    private final List<BlockPos> houseBlueprint = new ArrayList<>();
    private int houseStepIndex = 0;
    private boolean houseBuilt = false;

    public Nyx3nEngine(Nyx3nConfig cfg) {
        this.cfg = cfg;
    }

    public String getStatusText() {
        return statusText;
    }

    public String getRadarText() {
        return radarText;
    }

    public void resetHousePlan() {
        houseBuilt = false;
        houseOrigin = null;
        houseBlueprint.clear();
        houseStepIndex = 0;
    }

    public boolean toggleMaster(MinecraftClient client) {
        cfg.masterEnabled = !cfg.masterEnabled;
        if (!cfg.masterEnabled) {
            forceStop(client);
        } else {
            skippedBlocks.clear();
            statusText = "GUARDING";
        }
        return cfg.masterEnabled;
    }

    public void pauseForGui(MinecraftClient client) {
        if (client != null) {
            stopBreaking(client);
            releaseAllKeys(client);
        }
    }

    public void forceStop(MinecraftClient client) {
        if (client != null) {
            stopBreaking(client);
            releaseAllKeys(client);
        }
        currentGoalBlock = null;
        vengeanceTarget = null;
        statusText = "PAUSED";
    }

    public void tick(MinecraftClient client) {
        if (!cfg.masterEnabled) {
            return;
        }

        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        if (player == null || world == null || client.interactionManager == null) {
            return;
        }

        if (client.currentScreen != null) {
            stopBreaking(client);
            releaseAllKeys(client);
            statusText = "PAUSED (MENU)";
            return;
        }

        if (placeCooldown > 0) placeCooldown--;
        if (attackDelayTicks > 0) attackDelayTicks--;
        if (vengeanceTimer > 0) {
            vengeanceTimer--;
            if (vengeanceTimer == 0) vengeanceTarget = null;
        }
        strafeFlipTimer++;
        if (strafeFlipTimer > 26) {
            strafeDir = -strafeDir;
            strafeFlipTimer = 0;
        }
        skipClearTimer++;
        if (skipClearTimer > 360) {
            skippedBlocks.clear();
            skipClearTimer = 0;
        }

        // 100% Client-Side First-Hit Detection (Players + Any Mob!)
        detectFirstHitAttacker(player, world);
        updateMobRadar(player, world);

        if (cfg.waterRescue && player.isTouchingWater()) {
            client.options.jumpKey.setPressed(true);
        }

        // Priority 1: Survival Auto-Eat
        if (cfg.autoEat && handleAutoEat(client, player)) {
            return;
        }

        // Priority 2: Anti-Creeper 12-Block Radar
        if (cfg.antiCreeper && handleAntiCreeper(client, player, world)) {
            return;
        }

        // Priority 3: Iron Golem 3-Block Pillar Cheese
        if (cfg.ironGolemCheese && handleIronGolemCheese(client, player, world)) {
            return;
        }

        // Priority 4: HT3 PRO COMBAT (First-Hit Player Retaliation + Hostile Mobs!)
        if ((cfg.autoCombat || cfg.playerRetaliate) && handleHt3Combat(client, player, world)) {
            return;
        }

        client.options.useKey.setPressed(false);

        // Priority 5: Auto-Collect Nearby Dropped Items (only when farming/mining/building)
        if (cfg.autoCollectDrops && (cfg.treeChopper || cfg.autoMining || cfg.buildHouse)
                && handleCollectDrops(client, player, world)) {
            return;
        }

        // Priority 6: User-Selected Tasks
        if (cfg.buildHouse && !houseBuilt) {
            int blocks = countHotbarBuildingBlocks(player);
            if (blocks >= 16) {
                handleHouseBuilding(client, player, world);
                return;
            } else if (cfg.treeChopper) {
                handleTreeChopping(client, player, world);
                return;
            } else {
                stopBreaking(client);
                releaseAllKeys(client);
                statusText = "NEED BLOCKS (16+)";
                return;
            }
        }

        if (cfg.treeChopper) {
            if (handleTreeChopping(client, player, world)) {
                return;
            }
        }

        if (cfg.autoMining) {
            if (handleMining(client, player, world)) {
                return;
            }
        }

        // Release keys cleanly when just guarding/waiting for first hit
        if (activeBreakPos != null) {
            stopBreaking(client);
        }
        statusText = cfg.playerRetaliate ? "GUARDING (PvP+Mob)" : "GUARDING (SAFE)";
    }

    private void detectFirstHitAttacker(ClientPlayerEntity player, ClientWorld world) {
        // Check direct synced attacker first
        LivingEntity synced = player.getAttacker();
        if (synced != null && synced.isAlive() && synced != player && !(synced instanceof CreeperEntity)) {
            if (synced instanceof PlayerEntity) {
                if (cfg.playerRetaliate) {
                    lockVengeance(player, synced);
                    return;
                }
            } else if (cfg.autoCombat) {
                lockVengeance(player, synced);
                return;
            }
        }

        // Client-side reliable trigger: new hit frame (hurtTime jumped up!)
        boolean justGotHit = player.hurtTime > lastHurtTime && player.hurtTime >= 7;
        lastHurtTime = player.hurtTime;

        if (!justGotHit) {
            return;
        }

        // Find who hit us within 6.5 blocks (prioritize swinging Players or nearest Mob!)
        Box near = player.getBoundingBox().expand(6.5, 4.0, 6.5);
        List<LivingEntity> candidates = world.getEntitiesByClass(
                LivingEntity.class,
                near,
                e -> e.isAlive() && e != player && !e.isSpectator() && !(e instanceof CreeperEntity)
        );

        LivingEntity bestAttacker = null;
        double bestScore = Double.MAX_VALUE;

        for (LivingEntity e : candidates) {
            boolean isPlayer = (e instanceof PlayerEntity);
            if (isPlayer && !cfg.playerRetaliate) continue;
            if (!isPlayer && !cfg.autoCombat) continue;

            double dist = Math.sqrt(player.squaredDistanceTo(e));
            double score = dist;
            // Strong bonus if this player/mob is actively swinging their arm right as we got hit!
            if (e.handSwinging) {
                score -= 3.5;
            }
            if (isPlayer) {
                score -= 1.0;
            }
            if (score < bestScore) {
                bestScore = score;
                bestAttacker = e;
            }
        }

        if (bestAttacker != null) {
            lockVengeance(player, bestAttacker);
        }
    }

    private void lockVengeance(ClientPlayerEntity player, LivingEntity attacker) {
        boolean isNew = (vengeanceTarget == null || !vengeanceTarget.equals(attacker));
        vengeanceTarget = attacker;
        vengeanceTimer = 300; // Lock on for 15 seconds (resets on every hit!)
        if (isNew) {
            player.sendMessage(
                    Text.literal("\u00A7c[NYX3N v4] \u00A7eRetaliating vs \u00A7f" + attacker.getName().getString() + "!"),
                    true
            );
        }
    }

    private boolean isThreatMob(LivingEntity e) {
        return (e instanceof HostileEntity)
                || (e instanceof SlimeEntity)
                || (e instanceof PhantomEntity);
    }

    private void updateMobRadar(ClientPlayerEntity player, ClientWorld world) {
        if (!cfg.mobRadarHud) {
            radarText = "";
            return;
        }
        if (vengeanceTarget != null && vengeanceTarget.isAlive()) {
            int dist = (int) Math.round(Math.sqrt(player.squaredDistanceTo(vengeanceTarget)));
            radarText = "Target: " + vengeanceTarget.getName().getString() + " (" + dist + "m)";
            return;
        }
        Box box = player.getBoundingBox().expand(14.0, 6.0, 14.0);
        List<LivingEntity> threats = world.getEntitiesByClass(
                LivingEntity.class, box, e -> e.isAlive() && e != player && !e.isSpectator() && isThreatMob(e)
        );
        if (threats.isEmpty()) {
            radarText = "Radar: Safe";
            return;
        }
        LivingEntity closest = null;
        double minSq = Double.MAX_VALUE;
        for (LivingEntity h : threats) {
            double dSq = player.squaredDistanceTo(h);
            if (dSq < minSq) {
                minSq = dSq;
                closest = h;
            }
        }
        if (closest != null) {
            int dist = (int) Math.round(Math.sqrt(minSq));
            radarText = "Radar: " + closest.getType().getName().getString() + " (" + dist + "m | x" + threats.size() + ")";
        }
    }

    private boolean handleAutoEat(MinecraftClient client, ClientPlayerEntity player) {
        boolean needsFood = player.getHealth() < 12.0f || player.getHungerManager().getFoodLevel() < 14;
        if (!needsFood) return false;
        int foodSlot = findFoodSlot(player);
        if (foodSlot == -1) return false;
        stopBreaking(client);
        releaseMovementKeys(client);
        player.getInventory().setSelectedSlot(foodSlot);
        client.options.useKey.setPressed(true);
        statusText = "AUTO-EATING";
        return true;
    }

    private boolean handleAntiCreeper(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
        Box box = player.getBoundingBox().expand(12.0, 5.0, 12.0);
        List<CreeperEntity> creepers = world.getEntitiesByClass(
                CreeperEntity.class, box, c -> c.isAlive() && !c.isSpectator()
        );
        if (creepers.isEmpty()) return false;

        CreeperEntity nearest = null;
        double minSq = Double.MAX_VALUE;
        for (CreeperEntity c : creepers) {
            double dSq = player.squaredDistanceTo(c);
            if (dSq < minSq) {
                minSq = dSq;
                nearest = c;
            }
        }
        if (nearest == null || minSq > 144.0) return false;

        stopBreaking(client);
        client.options.useKey.setPressed(false);

        Vec3d pPos = new Vec3d(player.getX(), player.getY(), player.getZ());
        Vec3d cPos = new Vec3d(nearest.getX(), nearest.getY(), nearest.getZ());
        Vec3d away = pPos.subtract(cPos);
        if (away.lengthSquared() < 0.01) away = new Vec3d(1, 0, 0);
        Vec3d runTarget = pPos.add(away.normalize().multiply(8.0));
        lookAt(player, runTarget.add(0, 1.2, 0));
        client.options.forwardKey.setPressed(true);
        client.options.backKey.setPressed(false);
        client.options.leftKey.setPressed(false);
        client.options.rightKey.setPressed(false);
        client.options.sprintKey.setPressed(true);
        client.options.jumpKey.setPressed(cfg.autoJump && player.horizontalCollision);

        statusText = "CREEPER! (" + (int) Math.round(Math.sqrt(minSq)) + "m RUN)";
        return true;
    }

    private boolean handleIronGolemCheese(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
        Box box = player.getBoundingBox().expand(10.0, 6.0, 10.0);
        List<IronGolemEntity> golems = world.getEntitiesByClass(
                IronGolemEntity.class, box, g -> g.isAlive() && !g.isSpectator()
        );
        if (golems.isEmpty()) return false;

        IronGolemEntity golem = golems.get(0);
        stopBreaking(client);
        client.options.useKey.setPressed(false);

        double heightAboveGolem = player.getY() - golem.getY();
        if (heightAboveGolem < 2.4) {
            if (selectBuildingBlock(player) == -1) {
                statusText = "GOLEM! NEED 3 BLOCKS";
                return false;
            }
            releaseMovementKeys(client);
            player.setPitch(89.5f);
            client.options.jumpKey.setPressed(true);

            BlockPos belowFeet = BlockPos.ofFloored(player.getX(), player.getY() - 0.1, player.getZ());
            BlockPos support = belowFeet.down();
            if (placeCooldown == 0
                    && !player.isOnGround()
                    && world.getBlockState(belowFeet).isReplaceable()
                    && !world.getBlockState(support).isReplaceable()
                    && client.interactionManager != null) {
                Vec3d hitPos = Vec3d.ofCenter(support).add(0, 0.5, 0);
                BlockHitResult hit = new BlockHitResult(hitPos, Direction.UP, support, false);
                client.interactionManager.interactBlock(player, Hand.MAIN_HAND, hit);
                player.swingHand(Hand.MAIN_HAND);
                placeCooldown = 2;
            }
            statusText = "GOLEM PILLAR (" + String.format("%.1f", Math.max(0, heightAboveGolem)) + "/3)";
            return true;
        }

        releaseMovementKeys(client);
        client.options.jumpKey.setPressed(false);

        boolean holdingSword = cfg.autoTool && selectHotbarTag(player, ItemTags.SWORDS);
        boolean holdingAxe = cfg.autoTool && !holdingSword && selectHotbarTag(player, ItemTags.AXES);

        Vec3d aim = new Vec3d(golem.getX(), golem.getY() + golem.getHeight() * 0.7, golem.getZ());
        lookAt(player, aim);

        double distSq = player.squaredDistanceTo(golem);
        float cd = player.getAttackCooldownProgress(0.0f);
        if (distSq <= 18.0 && cd >= 1.0f && attackDelayTicks <= 0 && client.interactionManager != null) {
            client.interactionManager.attackEntity(player, golem);
            player.swingHand(Hand.MAIN_HAND);
            attackDelayTicks = holdingSword ? 13 : (holdingAxe ? 20 : 10);
        }

        statusText = "GOLEM CHEESE (" + Math.min(100, Math.round(cd * 100.0f)) + "%)";
        return true;
    }

    private boolean handleHt3Combat(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
        LivingEntity target = null;
        int nearbyCount = 0;

        // Priority A: First-hit attacker (Player friend OR Mob!)
        if (vengeanceTarget != null && vengeanceTarget.isAlive() && !vengeanceTarget.isSpectator()
                && player.squaredDistanceTo(vengeanceTarget) <= 225.0) {
            target = vengeanceTarget;
            nearbyCount = 1;
        } else {
            vengeanceTarget = null;
        }

        // Priority B: Nearby hostile mobs (only if Auto Combat is ON)
        if (cfg.autoCombat) {
            Box scanBox = player.getBoundingBox().expand(9.0, 4.5, 9.0);
            List<LivingEntity> threats = world.getEntitiesByClass(
                    LivingEntity.class,
                    scanBox,
                    e -> e.isAlive() && e != player && !e.isSpectator()
                            && !(e instanceof CreeperEntity)
                            && isThreatMob(e)
            );
            for (LivingEntity mob : threats) {
                if (player.squaredDistanceTo(mob) <= 36.0) nearbyCount++;
            }
            if (target == null) {
                double bestSq = Double.MAX_VALUE;
                for (LivingEntity mob : threats) {
                    double dSq = player.squaredDistanceTo(mob);
                    if (dSq < bestSq) {
                        bestSq = dSq;
                        target = mob;
                    }
                }
            }
        }

        if (target == null) {
            critWaitTicks = 0;
            client.options.useKey.setPressed(false);
            return false;
        }

        stopBreaking(client);

        boolean isPvpTarget = (target instanceof PlayerEntity);
        boolean crowdMode = !isPvpTarget && cfg.ht3CrowdStrafe && nearbyCount >= 2;
        double distSq = player.squaredDistanceTo(target);

        if (cfg.lowHpRetreat && player.getHealth() <= 6.0f) {
            client.options.useKey.setPressed(false);
            Vec3d pPos = new Vec3d(player.getX(), player.getY(), player.getZ());
            Vec3d mPos = new Vec3d(target.getX(), target.getY(), target.getZ());
            Vec3d away = pPos.add(pPos.subtract(mPos).normalize().multiply(6.0));
            lookAt(player, away.add(0, 1.2, 0));
            client.options.forwardKey.setPressed(true);
            client.options.backKey.setPressed(false);
            client.options.leftKey.setPressed(false);
            client.options.rightKey.setPressed(false);
            client.options.sprintKey.setPressed(true);
            client.options.jumpKey.setPressed(cfg.autoJump && player.horizontalCollision);
            statusText = "LOW HP! RETREATING";
            return true;
        }

        boolean holdingSword = cfg.autoTool && selectHotbarTag(player, ItemTags.SWORDS);
        boolean holdingAxe = cfg.autoTool && !holdingSword && selectHotbarTag(player, ItemTags.AXES);

        Vec3d aimPos = new Vec3d(target.getX(), target.getY() + target.getHeight() * 0.65, target.getZ());
        lookAt(player, aimPos);

        float cooldown = player.getAttackCooldownProgress(0.0f);
        boolean cdReady = (cooldown >= 0.96f) && (attackDelayTicks <= 0);
        boolean isFallingCrit = !player.isOnGround() && player.getVelocity().y < -0.05 && !player.isTouchingWater();

        // Auto-Shield Block while cooldown recharges
        boolean hasOffhandShield = player.getOffHandStack().isOf(Items.SHIELD);
        if (cfg.autoShield && hasOffhandShield && !cdReady && distSq < 14.0 && !isFallingCrit) {
            client.options.useKey.setPressed(true);
        } else {
            client.options.useKey.setPressed(false);
        }

        if (crowdMode) {
            client.options.leftKey.setPressed(strafeDir < 0);
            client.options.rightKey.setPressed(strafeDir > 0);
            if (distSq < 7.8) {
                client.options.forwardKey.setPressed(false);
                client.options.backKey.setPressed(true);
                client.options.sprintKey.setPressed(false);
                client.options.jumpKey.setPressed(false);
            } else if (distSq > 12.25) {
                client.options.forwardKey.setPressed(true);
                client.options.backKey.setPressed(false);
                client.options.sprintKey.setPressed(false);
                client.options.jumpKey.setPressed(cfg.autoJump && player.horizontalCollision);
            } else {
                client.options.forwardKey.setPressed(false);
                client.options.backKey.setPressed(!cdReady);
                client.options.sprintKey.setPressed(false);
                boolean shouldJumpCrit = cfg.ht3CritCombo && cooldown >= 0.72f && attackDelayTicks <= 3
                        && player.isOnGround() && !player.isTouchingWater();
                client.options.jumpKey.setPressed(shouldJumpCrit);
            }
        } else {
            // HT3 1v1 PvP / Mob W-Tap + Circle-Strafe + Jump-Crit!
            client.options.leftKey.setPressed(distSq < 11.0 && strafeDir < 0);
            client.options.rightKey.setPressed(distSq < 11.0 && strafeDir > 0);

            if (distSq > 11.0) {
                client.options.forwardKey.setPressed(true);
                client.options.backKey.setPressed(false);
                client.options.sprintKey.setPressed(cfg.autoSprint);
                client.options.jumpKey.setPressed(cfg.autoJump && player.horizontalCollision);
                critWaitTicks = 0;
            } else if (cfg.ht3CritCombo && cooldown >= 0.70f && attackDelayTicks <= 3
                    && player.isOnGround() && !player.isTouchingWater()) {
                client.options.jumpKey.setPressed(true);
                client.options.forwardKey.setPressed(distSq > 6.5);
                client.options.backKey.setPressed(distSq < 4.0);
                client.options.sprintKey.setPressed(false);
                critWaitTicks = 0;
            } else if (!cdReady && distSq < 5.5) {
                client.options.jumpKey.setPressed(false);
                client.options.forwardKey.setPressed(false);
                client.options.backKey.setPressed(true);
                client.options.sprintKey.setPressed(false);
            } else {
                client.options.jumpKey.setPressed(false);
                client.options.forwardKey.setPressed(distSq > 7.5);
                client.options.backKey.setPressed(false);
                client.options.sprintKey.setPressed(distSq > 7.5);
            }
        }

        if (distSq <= 12.25 && cdReady && client.interactionManager != null) {
            boolean allowStrike = !cfg.ht3CritCombo || isFallingCrit || critWaitTicks >= 6 || player.isTouchingWater();
            if (allowStrike) {
                client.options.useKey.setPressed(false);
                client.interactionManager.attackEntity(player, target);
                player.swingHand(Hand.MAIN_HAND);
                attackDelayTicks = holdingSword ? 13 : (holdingAxe ? 20 : 10);
                critWaitTicks = 0;
            } else {
                critWaitTicks++;
            }
        }

        int cdPct = Math.min(100, Math.round(cooldown * 100.0f));
        String tag = isPvpTarget
                ? ("HT3 PvP " + target.getName().getString())
                : (crowdMode ? ("HT3 1v" + nearbyCount) : (isFallingCrit ? "HT3 CRIT" : "HT3 COMBO"));
        statusText = tag + " (" + cdPct + "%)";
        return true;
    }

    private boolean handleCollectDrops(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
        if (activeBreakPos != null) return false;
        Box box = player.getBoundingBox().expand(5.5, 2.5, 5.5);
        List<ItemEntity> items = world.getEntitiesByClass(
                ItemEntity.class, box, item -> item.isAlive() && !item.cannotPickup()
        );
        if (items.isEmpty()) return false;
        ItemEntity closest = items.get(0);
        if (player.squaredDistanceTo(closest) < 1.2) return false;
        moveToward(client, player, new Vec3d(closest.getX(), closest.getY() + 0.3, closest.getZ()));
        statusText = "COLLECTING DROPS";
        return true;
    }

    private boolean handleTreeChopping(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
        if (cfg.leafCleaner && clearImmediateBlockingLeaf(client, player, world)) {
            return true;
        }
        if (currentGoalBlock != null) {
            boolean stillLog = world.getBlockState(currentGoalBlock).isIn(BlockTags.LOGS);
            int dy = currentGoalBlock.getY() - BlockPos.ofFloored(player.getX(), player.getY(), player.getZ()).getY();
            if (!stillLog || dy > 4 || dy < -2 || skippedBlocks.contains(currentGoalBlock)) {
                stopBreaking(client);
                currentGoalBlock = null;
            }
        }
        if (currentGoalBlock == null) {
            currentGoalBlock = findReachableTreeLog(world, player, 18);
        }
        if (currentGoalBlock == null) {
            stopBreaking(client);
            wander(client, player, "SEARCHING TREES");
            return false;
        }
        if (cfg.autoTool) selectHotbarTag(player, ItemTags.AXES);
        mineBlockSmart(client, player, world, currentGoalBlock, "CHOPPING TREE");
        return true;
    }

    private boolean clearImmediateBlockingLeaf(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
        if (currentGoalBlock == null) return false;
        Vec3d pPos = new Vec3d(player.getX(), player.getY(), player.getZ());
        Vec3d dirVec = Vec3d.ofCenter(currentGoalBlock).subtract(pPos);
        Vec3d horiz = new Vec3d(dirVec.x, 0, dirVec.z);
        if (horiz.lengthSquared() < 0.05) return false;
        Vec3d step = horiz.normalize();

        BlockPos frontEye = BlockPos.ofFloored(player.getX() + step.x * 1.1, player.getEyeY(), player.getZ() + step.z * 1.1);
        BlockPos frontFeet = BlockPos.ofFloored(player.getX() + step.x * 1.1, player.getY() + 0.5, player.getZ() + step.z * 1.1);

        BlockPos leafToCut = null;
        if (world.getBlockState(frontEye).isIn(BlockTags.LEAVES)) leafToCut = frontEye;
        else if (world.getBlockState(frontFeet).isIn(BlockTags.LEAVES)) leafToCut = frontFeet;
        if (leafToCut == null) return false;

        releaseMovementKeys(client);
        Vec3d eyePos = new Vec3d(player.getX(), player.getEyeY(), player.getZ());
        lookAt(player, Vec3d.ofCenter(leafToCut));
        breakSingleTick(client, player, world, leafToCut, getBestFace(eyePos, leafToCut), "CUTTING LEAVES");
        return true;
    }

    private boolean handleMining(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
        if (currentGoalBlock != null) {
            if (!isDesiredMiningBlock(world.getBlockState(currentGoalBlock)) || skippedBlocks.contains(currentGoalBlock)) {
                stopBreaking(client);
                currentGoalBlock = null;
            }
        }
        if (currentGoalBlock == null) {
            BlockPos center = BlockPos.ofFloored(player.getX(), player.getY(), player.getZ());
            currentGoalBlock = findNearestReachableBlock(world, center, 14, this::isOreBlock);
            if (currentGoalBlock == null) {
                currentGoalBlock = findNearestReachableBlock(world, center, 10, this::isStoneBlock);
            }
        }
        if (currentGoalBlock == null) {
            stopBreaking(client);
            wander(client, player, "SEARCHING ORES");
            return false;
        }
        if (cfg.autoTool) selectHotbarTag(player, ItemTags.PICKAXES);
        mineBlockSmart(client, player, world, currentGoalBlock, "MINING");
        return true;
    }

    private void mineBlockSmart(MinecraftClient client, ClientPlayerEntity player, ClientWorld world, BlockPos goalBlock, String taskLabel) {
        Vec3d eyePos = new Vec3d(player.getX(), player.getEyeY(), player.getZ());
        Vec3d goalCenter = Vec3d.ofCenter(goalBlock);

        double dx = goalCenter.x - player.getX();
        double dz = goalCenter.z - player.getZ();
        double horizDistSq = dx * dx + dz * dz;
        double fullDistSq = eyePos.squaredDistanceTo(goalCenter);

        if (horizDistSq < 4.5 && fullDistSq > 18.0) {
            stopBreaking(client);
            skippedBlocks.add(goalBlock);
            currentGoalBlock = null;
            statusText = "SKIPPING HIGH LOG";
            return;
        }

        if (fullDistSq > 16.0) {
            stopBreaking(client);
            moveToward(client, player, new Vec3d(goalCenter.x, player.getY() + 1.0, goalCenter.z));
            Vec3d nowPos = new Vec3d(player.getX(), player.getY(), player.getZ());
            if (lastWalkPos != null && nowPos.squaredDistanceTo(lastWalkPos) < 0.002) {
                walkStuckTicks++;
                if (walkStuckTicks > 40) {
                    skippedBlocks.add(goalBlock);
                    currentGoalBlock = null;
                    walkStuckTicks = 0;
                }
            } else {
                walkStuckTicks = 0;
            }
            lastWalkPos = nowPos;
            statusText = taskLabel + " (WALKING)";
            return;
        }

        walkStuckTicks = 0;
        releaseMovementKeys(client);
        lookAt(player, goalCenter);

        BlockPos actualBreakTarget = goalBlock;
        Direction hitSide = getBestFace(eyePos, goalBlock);

        BlockHitResult ray = world.raycast(new RaycastContext(
                eyePos, goalCenter, RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, player
        ));

        if (ray.getType() == HitResult.Type.BLOCK && !ray.getBlockPos().equals(goalBlock)) {
            BlockPos blockerPos = ray.getBlockPos();
            BlockState blockerState = world.getBlockState(blockerPos);
            if (cfg.leafCleaner && (blockerState.isIn(BlockTags.LEAVES) || blockerState.isIn(BlockTags.DIRT) || blockerState.isReplaceable())) {
                actualBreakTarget = blockerPos;
                hitSide = ray.getSide();
                taskLabel = "CUTTING LEAVES";
            } else {
                stopBreaking(client);
                skippedBlocks.add(goalBlock);
                currentGoalBlock = null;
                statusText = "RE-ROUTING";
                return;
            }
        } else if (ray.getType() == HitResult.Type.BLOCK) {
            hitSide = ray.getSide();
        }

        if (cfg.leafCleaner && client.crosshairTarget instanceof BlockHitResult crossHit
                && crossHit.getType() == HitResult.Type.BLOCK
                && !crossHit.getBlockPos().equals(goalBlock)) {
            if (world.getBlockState(crossHit.getBlockPos()).isIn(BlockTags.LEAVES)) {
                actualBreakTarget = crossHit.getBlockPos();
                hitSide = crossHit.getSide();
                taskLabel = "CUTTING LEAVES";
            }
        }

        lookAt(player, Vec3d.ofCenter(actualBreakTarget));
        breakSingleTick(client, player, world, actualBreakTarget, hitSide, taskLabel);
    }

    private void breakSingleTick(MinecraftClient client, ClientPlayerEntity player, ClientWorld world, BlockPos targetPos, Direction hitSide, String taskLabel) {
        if (client.interactionManager == null) return;
        if (world.getBlockState(targetPos).isAir()) {
            stopBreaking(client);
            if (targetPos.equals(currentGoalBlock)) currentGoalBlock = null;
            return;
        }
        if (!targetPos.equals(activeBreakPos)) {
            stopBreaking(client);
            activeBreakPos = targetPos;
            breakTicks = 0;
            client.interactionManager.attackBlock(targetPos, hitSide);
        } else {
            client.interactionManager.updateBlockBreakingProgress(targetPos, hitSide);
        }
        client.options.attackKey.setPressed(true);
        if (breakTicks % 3 == 0) player.swingHand(Hand.MAIN_HAND);
        breakTicks++;
        if (breakTicks > 140) {
            stopBreaking(client);
            skippedBlocks.add(targetPos);
            currentGoalBlock = null;
        }
        statusText = taskLabel;
    }

    private void stopBreaking(MinecraftClient client) {
        if (activeBreakPos != null && client.interactionManager != null) {
            client.interactionManager.cancelBlockBreaking();
        }
        activeBreakPos = null;
        breakTicks = 0;
        client.options.attackKey.setPressed(false);
    }

    private BlockPos findReachableTreeLog(ClientWorld world, ClientPlayerEntity player, int radius) {
        BlockPos center = BlockPos.ofFloored(player.getX(), player.getY(), player.getZ());
        Vec3d eyePos = new Vec3d(player.getX(), player.getEyeY(), player.getZ());
        BlockPos best = null;
        double bestScore = Double.MAX_VALUE;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -1; dy <= 3; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    BlockPos pos = center.add(dx, dy, dz);
                    if (skippedBlocks.contains(pos)) continue;
                    if (!world.getBlockState(pos).isIn(BlockTags.LOGS)) continue;
                    double dist = Math.sqrt(pos.getSquaredDistance(center));
                    double score = dist + Math.abs(dy) * 2.2;
                    BlockHitResult ray = world.raycast(new RaycastContext(
                            eyePos, Vec3d.ofCenter(pos), RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, player
                    ));
                    if (ray.getType() == HitResult.Type.BLOCK && !ray.getBlockPos().equals(pos)) {
                        BlockState hitState = world.getBlockState(ray.getBlockPos());
                        score += hitState.isIn(BlockTags.LEAVES) ? 2.5 : 14.0;
                    }
                    if (score < bestScore) {
                        bestScore = score;
                        best = pos;
                    }
                }
            }
        }
        return best;
    }

    private BlockPos findNearestReachableBlock(ClientWorld world, BlockPos center, int radius, Predicate<BlockState> matcher) {
        BlockPos best = null;
        double bestDistSq = Double.MAX_VALUE;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -2; dy <= 3; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    BlockPos pos = center.add(dx, dy, dz);
                    if (skippedBlocks.contains(pos)) continue;
                    if (matcher.test(world.getBlockState(pos))) {
                        double dSq = pos.getSquaredDistance(center);
                        if (dSq < bestDistSq) {
                            bestDistSq = dSq;
                            best = pos;
                        }
                    }
                }
            }
        }
        return best;
    }

    private void handleHouseBuilding(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
        stopBreaking(client);
        if (houseOrigin == null) {
            houseOrigin = BlockPos.ofFloored(player.getX(), player.getY(), player.getZ()).add(2, 0, 2);
            buildStarterHouseBlueprint(houseOrigin);
            houseStepIndex = 0;
        }
        while (houseStepIndex < houseBlueprint.size()) {
            BlockPos target = houseBlueprint.get(houseStepIndex);
            if (!world.getBlockState(target).isReplaceable()) houseStepIndex++;
            else break;
        }
        if (houseStepIndex >= houseBlueprint.size()) {
            releaseAllKeys(client);
            houseBuilt = true;
            cfg.buildHouse = false;
            statusText = "HOUSE COMPLETE!";
            return;
        }
        if (selectBuildingBlock(player) == -1) {
            releaseAllKeys(client);
            statusText = "NEED BLOCKS FOR HOUSE";
            return;
        }
        BlockPos target = houseBlueprint.get(houseStepIndex);
        Vec3d targetCenter = Vec3d.ofCenter(target);
        Vec3d playerPos = new Vec3d(player.getX(), player.getY(), player.getZ());
        if (playerPos.squaredDistanceTo(targetCenter) > 14.0) {
            moveToward(client, player, targetCenter);
            statusText = "BUILDING (" + houseStepIndex + "/" + houseBlueprint.size() + ")";
            return;
        }
        releaseMovementKeys(client);
        lookAt(player, targetCenter);
        if (placeCooldown == 0 && client.interactionManager != null) {
            BlockHitResult hit = findPlacementHit(world, target);
            if (hit != null) {
                client.interactionManager.interactBlock(player, Hand.MAIN_HAND, hit);
                player.swingHand(Hand.MAIN_HAND);
                placeCooldown = 3;
            } else {
                houseStepIndex++;
            }
        }
        statusText = "BUILDING (" + houseStepIndex + "/" + houseBlueprint.size() + ")";
    }

    private void buildStarterHouseBlueprint(BlockPos origin) {
        houseBlueprint.clear();
        for (int y = 0; y < 3; y++) {
            for (int x = -2; x <= 2; x++) {
                for (int z = -2; z <= 2; z++) {
                    boolean isPerimeter = (x == -2 || x == 2 || z == -2 || z == 2);
                    boolean isDoorway = (z == 2 && x == 0 && (y == 0 || y == 1));
                    if (isPerimeter && !isDoorway) houseBlueprint.add(origin.add(x, y, z));
                }
            }
        }
        for (int x = -2; x <= 2; x++) {
            for (int z = -2; z <= 2; z++) {
                houseBlueprint.add(origin.add(x, 3, z));
            }
        }
    }

    private BlockHitResult findPlacementHit(ClientWorld world, BlockPos target) {
        Direction[] order = {Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP};
        for (Direction dir : order) {
            BlockPos support = target.offset(dir);
            if (!world.getBlockState(support).isReplaceable()) {
                Direction placeSide = dir.getOpposite();
                Vec3d hitPos = Vec3d.ofCenter(support).add(
                        placeSide.getOffsetX() * 0.5,
                        placeSide.getOffsetY() * 0.5,
                        placeSide.getOffsetZ() * 0.5
                );
                return new BlockHitResult(hitPos, placeSide, support, false);
            }
        }
        return null;
    }

    private Direction getBestFace(Vec3d eyePos, BlockPos target) {
        Vec3d diff = eyePos.subtract(Vec3d.ofCenter(target));
        return Direction.getFacing(diff.x, diff.y, diff.z);
    }

    private void wander(MinecraftClient client, ClientPlayerEntity player, String label) {
        wanderTicks++;
        if (wanderTicks % 60 == 0) player.setYaw(player.getYaw() + 45.0f);
        client.options.forwardKey.setPressed(true);
        client.options.backKey.setPressed(false);
        client.options.leftKey.setPressed(false);
        client.options.rightKey.setPressed(false);
        client.options.sprintKey.setPressed(false);
        client.options.jumpKey.setPressed(cfg.autoJump && player.horizontalCollision);
        statusText = label;
    }

    private void moveToward(MinecraftClient client, ClientPlayerEntity player, Vec3d target) {
        lookAt(player, target);
        client.options.forwardKey.setPressed(true);
        client.options.backKey.setPressed(false);
        client.options.leftKey.setPressed(false);
        client.options.rightKey.setPressed(false);
        client.options.sprintKey.setPressed(cfg.autoSprint);
        client.options.jumpKey.setPressed(cfg.autoJump && player.horizontalCollision);
    }

    private void lookAt(ClientPlayerEntity player, Vec3d target) {
        double dx = target.x - player.getX();
        double dy = target.y - player.getEyeY();
        double dz = target.z - player.getZ();
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float targetPitch = (float) (-Math.toDegrees(Math.atan2(dy, horizontal)));
        player.setYaw(MathHelper.wrapDegrees(targetYaw));
        player.setPitch(MathHelper.clamp(targetPitch, -90.0f, 90.0f));
    }

    private boolean isDesiredMiningBlock(BlockState state) {
        return isOreBlock(state) || isStoneBlock(state);
    }

    private boolean isOreBlock(BlockState state) {
        Block b = state.getBlock();
        return b == Blocks.COAL_ORE || b == Blocks.DEEPSLATE_COAL_ORE
                || b == Blocks.IRON_ORE || b == Blocks.DEEPSLATE_IRON_ORE
                || b == Blocks.COPPER_ORE || b == Blocks.DEEPSLATE_COPPER_ORE
                || b == Blocks.GOLD_ORE || b == Blocks.DEEPSLATE_GOLD_ORE
                || b == Blocks.DIAMOND_ORE || b == Blocks.DEEPSLATE_DIAMOND_ORE;
    }

    private boolean isStoneBlock(BlockState state) {
        Block b = state.getBlock();
        return b == Blocks.STONE || b == Blocks.COBBLESTONE || b == Blocks.DEEPSLATE;
    }

    private boolean selectHotbarTag(ClientPlayerEntity player, TagKey<Item> tag) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.isIn(tag)) {
                player.getInventory().setSelectedSlot(i);
                return true;
            }
        }
        return false;
    }

    private int findFoodSlot(ClientPlayerEntity player) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.contains(DataComponentTypes.FOOD)) return i;
        }
        return -1;
    }

    private int countHotbarBuildingBlocks(ClientPlayerEntity player) {
        int count = 0;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.getItem() instanceof BlockItem) count += stack.getCount();
        }
        return count;
    }

    private int selectBuildingBlock(ClientPlayerEntity player) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.isIn(ItemTags.PLANKS)) {
                player.getInventory().setSelectedSlot(i);
                return i;
            }
        }
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.getItem() instanceof BlockItem) {
                player.getInventory().setSelectedSlot(i);
                return i;
            }
        }
        return -1;
    }

    private void releaseMovementKeys(MinecraftClient client) {
        client.options.forwardKey.setPressed(false);
        client.options.backKey.setPressed(false);
        client.options.leftKey.setPressed(false);
        client.options.rightKey.setPressed(false);
        client.options.jumpKey.setPressed(false);
        client.options.sprintKey.setPressed(false);
    }

    private void releaseAllKeys(MinecraftClient client) {
        releaseMovementKeys(client);
        client.options.useKey.setPressed(false);
        client.options.attackKey.setPressed(false);
    }
}
