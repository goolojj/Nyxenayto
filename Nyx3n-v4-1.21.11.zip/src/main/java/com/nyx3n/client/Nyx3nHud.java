package com.nyx3n.client;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

public final class Nyx3nHud {
    private Nyx3nHud() {}

    public static void register() {
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.of(Nyx3nClientMod.MOD_ID, "status_hud"),
                Nyx3nHud::render
        );
    }

    private static void render(DrawContext drawContext, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.options.hudHidden) {
            return;
        }

        Nyx3nConfig cfg = Nyx3nClientMod.getConfig();
        Nyx3nEngine engine = Nyx3nClientMod.getEngine();
        boolean enabled = cfg.masterEnabled;

        List<String> lines = new ArrayList<>();
        lines.add(enabled ? "NYX3N v4 [M]: ACTIVE" : "NYX3N v4 [M]: PAUSED");

        if (enabled) {
            lines.add("Task: " + engine.getStatusText());
            if (cfg.mobRadarHud && !engine.getRadarText().isEmpty()) {
                lines.add(engine.getRadarText());
            }
            if (cfg.nightAlert && client.world != null) {
                long tod = client.world.getTimeOfDay() % 24000L;
                if (tod >= 12500L && tod <= 23500L) {
                    lines.add("ALERT: NIGHT TIME!");
                }
            }
        }

        int padding = 5;
        int lineHeight = 10;
        int maxW = 0;
        for (String line : lines) {
            maxW = Math.max(maxW, client.textRenderer.getWidth(line));
        }
        int width = maxW + padding * 2 + 4;
        int height = lines.size() * lineHeight + padding * 2;

        int screenW = client.getWindow().getScaledWidth();
        int x;
        int y;
        if (cfg.hudPosition == 0) {
            x = Math.max(8, screenW - width - 8);
            y = 42;
        } else if (cfg.hudPosition == 1) {
            x = (screenW - width) / 2;
            y = 8;
        } else {
            x = 8;
            y = 8;
        }

        int bgColor = enabled ? 0xCC09121A : 0x99091016;
        int accentColor = enabled ? 0xFF10F5A8 : 0xFFEF4444;
        int borderColor = enabled ? 0xFF1E3F50 : 0xFF2B2428;

        drawContext.fill(x - 1, y - 1, x + width + 1, y + height + 1, borderColor);
        drawContext.fill(x, y, x + width, y + height, bgColor);
        drawContext.fill(x, y, x + 3, y + height, accentColor);

        for (int i = 0; i < lines.size(); i++) {
            int color = switch (i) {
                case 0 -> enabled ? 0xFF34F5C5 : 0xFFF87171;
                case 1 -> 0xFFFDE68A;
                default -> 0xFFFCA5A5;
            };
            drawContext.drawTextWithShadow(
                    client.textRenderer,
                    lines.get(i),
                    x + padding + 2,
                    y + padding + i * lineHeight,
                    color
            );
        }
    }
}
