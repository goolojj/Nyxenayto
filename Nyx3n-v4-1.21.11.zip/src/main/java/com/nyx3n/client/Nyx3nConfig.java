package com.nyx3n.client;

public class Nyx3nConfig {
    // Master is ON by default so individual toggles work immediately!
    // Action tasks (Tree/Mining/House/Golem) start OFF so nothing runs unexpectedly until you turn them ON.
    public boolean masterEnabled = true;

    // Page 1: Combat & Core Actions
    public boolean autoCombat = true;         // Fights hostile mobs + anyone who hits you
    public boolean playerRetaliate = true;    // Retaliates against any player/friend who hits you first!
    public boolean ht3CritCombo = true;       // HT3 Jump-Crit + W-Tap Combo
    public boolean ht3CrowdStrafe = true;     // HT3 1v4 Circle-Strafe & Back-Pedal
    public boolean autoShield = true;         // Offhand Shield block while recharging
    public boolean antiCreeper = true;        // 12-block Day/Night Creeper Radar
    public boolean treeChopper = false;       // Turn ON when you want wood
    public boolean autoMining = false;        // Turn ON when you want ore/stone mining
    public boolean buildHouse = false;        // Turn ON to build 5x5 starter shelter
    public boolean ironGolemCheese = false;   // Turn ON for 3-block pillar Iron Golem cheese

    // Page 2: Smart Survival, Movement & HUD
    public boolean autoEat = true;
    public boolean autoTool = true;
    public boolean autoCollectDrops = true;
    public boolean autoSprint = true;
    public boolean autoJump = true;
    public boolean waterRescue = true;
    public boolean lowHpRetreat = false;      // Off by default so you don't run mid-PvP unless enabled
    public boolean leafCleaner = true;
    public boolean mobRadarHud = true;
    public boolean nightAlert = true;

    // HUD Position: 0 = TOP_RIGHT (MJLauncher friendly), 1 = TOP_CENTER, 2 = TOP_LEFT
    public int hudPosition = 0;

    public String getHudPositionLabel() {
        return switch (hudPosition) {
            case 0 -> "TOP-RIGHT";
            case 1 -> "TOP-CENTER";
            default -> "TOP-LEFT";
        };
    }

    public void cycleHudPosition() {
        hudPosition = (hudPosition + 1) % 3;
    }

    public void panicStopAll() {
        masterEnabled = false;
        treeChopper = false;
        autoMining = false;
        buildHouse = false;
        autoCombat = false;
        playerRetaliate = false;
        ironGolemCheese = false;
    }
}
