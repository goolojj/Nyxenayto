package com.nyx3n.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class Nyx3nClientMod implements ClientModInitializer {
    public static final String MOD_ID = "nyx3nclient";

    private static KeyBinding menuKey;
    private static KeyBinding quickToggleKey;
    private static final Nyx3nConfig CONFIG = new Nyx3nConfig();
    private static final Nyx3nEngine ENGINE = new Nyx3nEngine(CONFIG);

    private static boolean greeted = false;
    private static boolean openMenuNextTick = false;

    public static Nyx3nConfig getConfig() {
        return CONFIG;
    }

    public static Nyx3nEngine getEngine() {
        return ENGINE;
    }

    @Override
    public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.nyx3nclient.menu",
                GLFW.GLFW_KEY_M,
                KeyBinding.Category.GAMEPLAY
        ));

        quickToggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.nyx3nclient.quick_toggle",
                GLFW.GLFW_KEY_N,
                KeyBinding.Category.GAMEPLAY
        ));

        Nyx3nHud.register();

        ClientSendMessageEvents.ALLOW_CHAT.register(message -> {
            String cmd = message.trim().toLowerCase();
            MinecraftClient client = MinecraftClient.getInstance();
            if (cmd.equals(".menu") || cmd.equals(".nyx3n")) {
                openMenuNextTick = true;
                return false;
            }
            if (cmd.equals(".on")) {
                if (!CONFIG.masterEnabled) ENGINE.toggleMaster(client);
                if (client.player != null) {
                    client.player.sendMessage(Text.literal("\u00A7b[NYX3N v4] \u00A7aACTIVE!"), true);
                }
                return false;
            }
            if (cmd.equals(".off")) {
                CONFIG.masterEnabled = false;
                ENGINE.forceStop(client);
                if (client.player != null) {
                    client.player.sendMessage(Text.literal("\u00A7b[NYX3N v4] \u00A7cPAUSED!"), true);
                }
                return false;
            }
            return true;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) {
                greeted = false;
                return;
            }

            if (!greeted) {
                greeted = true;
                client.player.sendMessage(
                        Text.literal("\u00A7b[NYX3N v4] \u00A7aLoaded & Ready! \u00A7fPress \u00A7eM \u00A7for chat \u00A7e.menu \u00A7f| \u00A7eN \u00A7fPause/Resume"),
                        false
                );
            }

            if (openMenuNextTick) {
                openMenuNextTick = false;
                ENGINE.pauseForGui(client);
                client.setScreen(new Nyx3nMenuScreen());
            }

            while (menuKey.wasPressed()) {
                if (client.currentScreen instanceof Nyx3nMenuScreen) {
                    client.setScreen(null);
                } else {
                    ENGINE.pauseForGui(client);
                    client.setScreen(new Nyx3nMenuScreen());
                }
            }

            while (quickToggleKey.wasPressed()) {
                boolean nowEnabled = ENGINE.toggleMaster(client);
                client.player.sendMessage(
                        Text.literal(nowEnabled
                                ? "\u00A7b[NYX3N v4] \u00A7aACTIVE"
                                : "\u00A7b[NYX3N v4] \u00A7cPAUSED"),
                        true
                );
            }

            ENGINE.tick(client);
        });
    }
}
